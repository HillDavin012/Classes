#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

int dynamicODM(vector<int> incArr, int i, int targ, int sum, vector<vector<int>> ODMmap)
{

	//Making sure we don't access out of bounds
	if (i >= incArr.size())
	{
		return 0;
	}
	//Stop recursion if our sum is above target value
	else if (sum > targ)
	{
		return 0;
	}
	else if (ODMmap[i][sum] != -1)
	{
		return ODMmap[i][sum];
	}
	//Lets see if we summed up to target value
	else if (sum == targ)
	{
		ODMmap[i][sum] = 1;
	}
	else
	{
		//Go left and right when you go left sum current index. When you go rigth just increment index. This will just get basic values that sum up to target
		ODMmap[i][sum] = dynamicODM(incArr, i, targ, sum + incArr[i], ODMmap) + dynamicODM(incArr, i + 1, targ, sum, ODMmap);
	}

	return ODMmap[i][sum];
}

int dynamicOM(vector<int> incArr, int i, int targ, int sum, vector<vector<int>> OMmap)
{

	//Making sure we don't access out of bounds
	if (i >= incArr.size())
	{
		return 0;
	}
	//Stop recursion if our sum is above target value
	else if (sum > targ)
	{
		return 0;
	}
	else if (OMmap[i][sum] != -1)
	{
		return OMmap[i][sum];
	}
	//Lets see if we summed up to target value
	else if (sum == targ)
	{
		OMmap[i][sum] = 1;
	}
	else
	{
		//Go left and right when you go left sum current index. When you go rigth just increment index. This will just get basic values that sum up to target
		OMmap[i][sum] = dynamicOM(incArr, 0, targ, sum + incArr[i], OMmap) + dynamicOM(incArr, i + 1, targ, sum, OMmap);
	}

	return OMmap[i][sum];
}

int main()
{

	int numProblems = 0;
	int targ = 0;
	int arrLength = 0;
	int digit = 0;
	int resultsODM = 0;
	int resultsOM = 0;
	vector<vector<int>> ODMmap;
	vector<vector<int>> OMmap;
	vector<int> tempVect;

	ifstream inputFile;
	ofstream outputFile;

	inputFile.open("input.txt");

	if (!inputFile.is_open())
	{
		cout << "Can't open input file!" << endl;
		return 0;
	}

	outputFile.open("output.txt");

	inputFile >> numProblems;

	for (int i = 0; i < numProblems; i++)
	{
		inputFile >> targ;
		inputFile >> arrLength;

		for (int i = 0; i < arrLength; i++)
		{
			inputFile >> digit;
			tempVect.push_back(digit);
		}

		ODMmap.resize(arrLength + 1, vector<int>(targ + 1, -1));
		OMmap.resize(arrLength + 1, vector<int>(targ + 1, -1));


		resultsODM = dynamicODM(tempVect, 0, targ, 0, ODMmap);
		resultsOM = dynamicOM(tempVect, 0, targ, 0, OMmap);

		outputFile << resultsOM << "\t" << resultsODM << endl;

		tempVect.clear();
		ODMmap.clear();
		OMmap.clear();
	}

	inputFile.close();
	outputFile.close();

	return 0;
}