Make sure Proj3.cpp and make file
are in the same directory. Then
run the command terminal in that
current directory as follows.


//*****COMPILE CODE ******//

To compile type 
--------------> "make"
--------------> "./buckets"

//*****COMPILE CODE ******//

NOTES:
This project was compiled on my
personal computer with VS 2015/17
and on the C4 computers with no 
errors with correct answers to 
all 3 test cases;