#include <iostream>
#include <vector>
#include <fstream>
#include <queue>
#include <map>

using namespace std;

struct Vertex
{
	vector<int> newVert;
	vector<Vertex*> Neighbors;
	int id;
	int sum;
};


struct Graph
{
	vector<Vertex> myVertecies;
};

int main()
{
	int num_buck = 0;
	ifstream inputFile;
	ofstream outputFile;


	inputFile.open("input.txt");

	if (!inputFile.is_open())
	{
		cout << "Can't open input file!" << endl;
		return 0;
	}

	inputFile >> num_buck;

	Graph g;
	int digit = 0;
	vector<int> temp;
	vector<int> master;
	int edges = 0;
	int count = 1;
	Vertex myVert;
	map<vector<int>, Vertex> mymapVert;


	for (int i = 0; i < num_buck; i++)
	{
		//Reading size of buckets
		inputFile >> digit;
		//Master vector to test against
		master.push_back(digit);
		//Creating temp vector with start size 0 and creating first Vertice
		myVert.newVert.push_back(0);
		temp.push_back(0);
	}
	myVert.id = count;
	myVert.sum = 0;
	mymapVert.insert(pair<vector<int>, Vertex>(temp, myVert));

	g.myVertecies.push_back(myVert);
	inputFile.close();
	cout << "Master size: " << master.size() << endl;

	digit = 0;

	master[0] += 1;
	cout << "Creating Nodes" << endl;
	while (temp[0] < master[0])
	{
		temp[num_buck - 1] += 1;
		if (temp[num_buck - 1] + 1 > master[num_buck - 1])
		{
			for (int i = num_buck - 1; i > -1; i--)
			{
				if (temp[i] > master[i])
				{
					temp[i - 1] += 1;

					for (int j = i; j < num_buck; j++)
					{
						temp[j] = 0;
					}
				}
			}
		}

		if (temp[0] < master[0])
		{
			count++;
			myVert.newVert = temp;
			myVert.id = count;
			digit = 0;
			for (int z = 0; z < num_buck; z++)
			{
				digit += temp[z];
			}
			myVert.sum = digit;
			mymapVert.insert(pair<vector<int>, Vertex>(temp, myVert));
			g.myVertecies.push_back(myVert);
		}
	}

	master[0] -= 1;

	cout << "Started Fill/Xtrans/Empty" << endl;
	for (int i = 0; i < count; i++)
	{
		//Fill
		for (int j = 0; j < num_buck; j++)
		{
			if (g.myVertecies.at(i).newVert.at(j) < master[j])
			{
				digit = master[j];
				vector<int> temp2 = g.myVertecies[i].newVert;
				temp2[j] = digit;
				Vertex *ptr = new Vertex;
				*ptr = mymapVert[temp2];
				g.myVertecies.at(i).Neighbors.push_back(ptr);

				edges++;
			}
		}

		//Empty
		for (int j = 0; j < num_buck; j++)
		{
			if (g.myVertecies.at(i).newVert.at(j) > 0)
			{
				vector<int> temp2 = g.myVertecies.at(i).newVert;
				temp2[j] = 0;
				Vertex *ptr = new Vertex;
				*ptr = mymapVert[temp2];
				g.myVertecies.at(i).Neighbors.push_back(ptr);
				edges++;
			}
		}

		//Transfer
		for (int k = 0; k < num_buck; k++)
		{
			for (int j = 0; j < num_buck; j++)
			{
				if (k != j)
				{
					if (g.myVertecies.at(i).newVert.at(k) != 0)
					{
						if (g.myVertecies.at(i).newVert.at(j) != master[j])
						{
							digit = g.myVertecies.at(i).newVert.at(k) + g.myVertecies.at(i).newVert.at(j);

							if (digit > master[j])
							{
								int sub = digit - master[j];// now j will equal max and k will equal sub
								vector<int> temp2 = g.myVertecies.at(i).newVert;
								Vertex *ptr = new Vertex;
								temp2[j] = master[j];
								temp2[k] = sub;
								*ptr = mymapVert[temp2];
								g.myVertecies.at(i).Neighbors.push_back(ptr);

								edges++;
							}
							else
							{
								vector<int> temp2 = g.myVertecies[i].newVert;
								Vertex *ptr = new Vertex;
								temp2[j] = digit;
								temp2[k] = 0;
								*ptr = mymapVert[temp2];
								g.myVertecies.at(i).Neighbors.push_back(ptr);

								edges++;
							}
						}
					}
				}
			}
		}
	}


	Vertex v;
	vector<int> check(count, 0);
	vector<int> vectSums(count, 0);
	vector <int> depths;
	check[0] = 1;
	int sum = 0;
	queue <Vertex> myque;
	queue<int> depthQue;
	depthQue.push(0);
	myque.push(g.myVertecies[0]);
	int depth = 0;
	cout << "starting BFS" << endl;
	int hardest_num = 0;
	int hardest_depth = 0;
	while (!myque.empty())
	{
		v = myque.front();
		depth = depthQue.front();
		myque.pop();
		depthQue.pop();
		sum = v.sum;
		Vertex *i = new Vertex;
		int length = g.myVertecies.at(v.id - 1).Neighbors.size();

		//going through the neighbors of the vector
		for (int l = 0; l < length; l++)
		{

			i = g.myVertecies.at(v.id - 1).Neighbors.at(l);
			if (check.at(i->id - 1) == 0)
			{
				sum = i->sum;
				check.at(i->id - 1) = 1;

				myque.push(*i);
				depthQue.push(depth + 1);
				if (vectSums.at(i->sum) != i->sum)
				{

					vectSums.at(i->sum) = i->sum;
					if (depth + 1 == hardest_depth)
					{
						if (hardest_num > i->sum)
						{
							hardest_num = i->sum;
						}
					}
					else
					{
						hardest_num = i->sum;
						hardest_depth = depth + 1;
					}
				}
			}
		}
	}
	outputFile.open("output.txt");
	outputFile << count << " " << edges << " " << hardest_num << " " << hardest_depth << endl;
	cout  << count << " " << edges << " " << hardest_num << " " << hardest_depth << endl;

	outputFile.close();


	return 0;
}



