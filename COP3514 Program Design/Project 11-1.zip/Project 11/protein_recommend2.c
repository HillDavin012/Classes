/*
protein_recommend.c
This program takes protein.txt and takes the information from its file
The program creates an output file with ".rcd" ending
The information from origianl file.txt gets sent to compare/qsort function to be sorted
Once the information is sorted, the top 5 with over 49 reviews only get written to output file
Davin Hill
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define STR_LEN 100

//Here I create the struct for the proteins
typedef struct protein
{
	char brand_name[STR_LEN];
	int inStock;
	int units_Sold;
	double customerReview;
	int num_reviews;
}protein;



int compare(const void *, const void *);

//Added command line prompt
int main(int argc, char *argv[])
{

	struct protein protein_powders[STR_LEN];

	int i;
	int t = 0;
	int num_protein = 0;

	char input_file[STR_LEN];
	char final_file[STR_LEN];

	//Copy string from command line and assign to varible input_file
	strcpy(input_file, argv[1]);

	//Creating final file
	sprintf(final_file, "%s.rcd", input_file);

	//Setting read and write files
	FILE *read = fopen(input_file, "r");
	FILE *write = fopen(final_file, "w");
 
	{

	   //Making sure file can get be opened and can read it
		if (read == NULL)
		{
			printf("Unable to open\n");

			return 0;
		}
		//Else start while loop to collect everything off of the file
		else
		{
			while (fscanf(read, "%d %d %lf %d %[^\n]s ", &protein_powders[num_protein].inStock, &protein_powders[num_protein].units_Sold, &protein_powders[num_protein].customerReview, &protein_powders[num_protein].num_reviews, protein_powders[num_protein].brand_name) != EOF)
			{
				//This counts the amount of protein powders their are
				num_protein++;
			}
		}

		
		//Takes info and sends it to qsort/compare function
		qsort(protein_powders, num_protein, sizeof(protein), compare);
 
		fprintf(write, "In sorted order:\r\n");
		//Starting print out for, but checking for only the ones we want by in stock and customer reviews
		for (i = 0; i < num_protein; i++)
		{
			if (protein_powders[i].inStock > 0)
			{
				//If statment catching num_reviews and times its executed only 5 times
				if (protein_powders[i].num_reviews > 49 && t < 5)
				{
					//Writing information to file
					fprintf(write, "%d\t %d\t %.1lf\t %d\t %s\r\n", protein_powders[i].inStock, protein_powders[i].units_Sold, protein_powders[i].customerReview, protein_powders[i].num_reviews, protein_powders[i].brand_name);
					t++;
				}
			}
			else
			{
				continue;
			}
		}

		//Close read/write
		fclose(read);
		fclose(write);

		return 0;

	}
}

//This gives qsort the value it needs to decide on sorting
int compare(const void *p, const void *q)
{
	
	 const protein *ptr1 = p;
	 const protein *ptr2 = q;

	 //Checking if values are greater or not
	 if (ptr1->customerReview > ptr2->customerReview)
	 {
		 return -1;
	 }
	 else if (ptr1->customerReview == ptr2->customerReview)
	 {
		 return 0;
	 }
	 else
	 {
		 return 1;
	 }
	 return 0;
}

