/*
equipment.c
This file holds all the functions to change and update and add to the list and delete
Davin Hill
*/

#include "equipment.h"
#include "readline.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>


//This function adds struct items to the list
struct equipment *append_to_list(struct equipment *list)
{	
	
	//Checking for available memory and assining to pointer p
	struct equipment *p = (struct equipment*)malloc(sizeof(struct equipment));

	//Starting location pointer at beggining of list
	struct equipment *location = list;
	
	//Additional pointer to help point to list keeping track of locations
	struct equipment *q = list;

	//Recieving information to be processed
	printf("Enter type: ");
	read_line(p->type, NAME_LEN);
	printf("\n");

	//Recieving information to be processed
	printf("Enter discription: ");
	read_line(p->description, NAME_LEN);
	printf("\n");

	//Recieving information to be processed
	printf("Enter quantity: ");
	scanf("%d", &p->quantity);
	printf("%d\n", p->quantity);

	//If list is empty or not found return p, making sure next node is NULL
	if (!q)
	{
		return p;
		p->next = NULL;
	}
	else
	{
		while (q != NULL)
		{
			//Making sure input isn't already on list
			if ((strcmp(q->type, p->type) == 0) && (strcmp(q->description, p->description) == 0))
			{
				printf("\nalready exists in the list.");
				return list;
			}
			//Comparing strings if input is greater, will wait to input until right location is reached
			if (strcmp(p->type, q->type) > 0) 
			{
				//Save location in location, then increment q pointer
				location = q;
				q = q->next;
			}
			//Comparing strings if input is less
			else if (strcmp(p->type, q->type) < 0) 
			{
				break;
			}
			//If input matches type
			else if (strcmp(p->type, q->type) == 0) 
			{
				//Checking if input is equal or less, then break
				if (strcmp(p->description, q->description) <= 0) 
				{
					break;
				}
				else 
				{
					//Save location in location, then increment q pointer
					location = q;
					q = q->next;
				}
			}
		}
		//If location is at beggining of list
		if (q == list) 
		{
			//This becomes new head of list
			p->next = list;
			list = p;
			return list;
		}
		else
		{
			//After first item on list
			p->next = q;
			location->next = p;
			return list;
		}
		//Set end of list to NULL
		p->next = NULL;
	}
	//Return if nothing hits
	return 0;
}

//This function updates current items in the list
void update(struct equipment *list)
{
	//Making sure list is created
	if (!list)
	{
		printf("Equipment list not found");
		return;
	}
	//Int for updating quantity 
	int add;

	//Checking for memory space and assigning it to pointer p
	struct equipment *p = (struct equipment*)malloc(sizeof(struct equipment));

	//Creating pointer and beggining at the start of list
	struct equipment *location = list;

	//Recieving information to be processed
	printf("Enter equipment type: ");
	read_line(p->type, NAME_LEN);
	printf("\n");

	//Recieving information to be processed
	printf("Enter equipment discription: ");
	read_line(p->description, NAME_LEN);
	printf("\n");

	//Recieving information to be processed
	printf("Enter new equipment quantity: ");
	scanf("%d", &add);

	//While location is not null keep looking
	while (location)
	{
		//Looking for the updated equipement the user requested
		if ((strcmp(location->type, p->type) == 0) && (strcmp(location->description, p->description) == 0))
		{
			//Once found, do update
			location->quantity = location->quantity + add;
			printf("%s, new quantity: %d\n", location->type, location->quantity);
			free(p);
			return;
		}
		//Go to next location
		location = location->next;
	}
}

//This function prints the list at the users request
void printList(struct equipment *list)
{
	//Creating pointer p to point to list
	struct equipment *p = list;

	printf("\n%s\t%s\t%s\n", "Equipment", "Description", "Quantity");

	//While p is not NULL print
	while (p)
	{
		printf("%s\t %s\t\t %d\n", p->type, p->description, p->quantity);
		p = p->next;
	}
}

//This function deletes requested node and fixes list order
struct equipment *delete_from_list(struct equipment *list)
{
	//Checking for available memory and assigning to pointer p
	struct equipment *p = (struct equipment*)malloc(sizeof(struct equipment));

	//Extra pointer to help keep track of location on list
	struct equipment *q = list;

	//Starting location pointer at beggining of list
	struct equipment *location = list;

	//Used to match to one to delete
	printf("Enter type: ");
	read_line(p->type, NAME_LEN);
	printf("\n");

	//Used to match to one to delete
	printf("Enter discription: ");
	read_line(p->description, NAME_LEN);
	printf("\n");

	if (!list)
	{
		printf("List is empty\n");
	}
	else
	{		
		//This is for first item on the list
		if (strcmp(location->type, p->type) == 0 && strcmp(location->description, p->description) == 0)
		{
			//Point list to next node, not to first, this deletes first node
			q = q->next;
			printf("Deleted\n");
			return q;
		}
		else
		{
			//Go through q until NULL
			while (q->next)
			{
				//Point location to (list->next) q->next
				location = q->next;
				//Check if location pointer matches input pointer, if so break saving location of pointer q (where the item needs to be deleted)
				if (strcmp(location->type, p->type) == 0 && strcmp(location->description, p->description) == 0)
				{
					break;
				}
				//Itterate through list
				q = q->next;
			}
			//As long as not deleting NULL node
			if (q->next != NULL)
			{
				//Move list to point to new locations
				q->next = location->next;
				printf("Deleted\n");
			}
			else
			{
				printf("Not Found\n");
			}
		}
	}
	return list;
}


//This function depoints to items on the list and frees memory
void clearList(struct equipment *list)
{

	struct equipment *p = list;
	struct equipment *temp;

	//Goes through list and frees items
	while (!p)
	{
		temp = p->next;
		free(p);
		p = temp;
	}

}