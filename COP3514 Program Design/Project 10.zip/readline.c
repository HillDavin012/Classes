/*
readline.c
This is the read line fuction for group equip
Davin Hill
*/

#include "readline.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

//This was part of the original file given, I only edited it slightly to show more output
int read_line(char str[], int n)
{
	int ch, i = 0;

	while (isspace(ch = getchar()))
		;
	printf("%c", ch);
	str[i++] = ch;
	while ((ch = getchar()) != '\n')
	{
		printf("%c", ch);
		if (i < n)
			str[i++] = ch;

	}
	str[i] = '\0';
	return i;
}