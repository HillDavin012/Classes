/*
readline.h
This is the readline header for readline
Davin Hill
*/

#ifndef READLINE_H
#define READLINE_H

int read_line(char str[], int n);

#endif