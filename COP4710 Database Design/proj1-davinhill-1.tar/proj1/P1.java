import java.io.*;
import java.util.*;


public class P1 
{
	
	boolean teams_by_city = false;
	boolean coaches_by_name = false;
	boolean search_coaches = false;
	
	/* Define data structures for holding the data here */
	public class Coaches 
	{
		String coachID, firstName, lastName, team;
		int season, seasonWin, seasonLoss, playoffWin, playoffLoss;
	}

	public class Teams
	{
		String teamID, location, name, league; 
	}
	
	
	ArrayList<Coaches> coaches = new ArrayList<Coaches>();
	ArrayList<Teams> teams   = new ArrayList<Teams>();
    
    public void run() 
    {    	
        CommandParser parser = new CommandParser();

        System.out.println("The mini-DB of NBA coaches and teams");
        System.out.println("Please enter a command.  Enter 'help' for a list of commands.");
        System.out.println();
        System.out.print("> "); 
        
        Command cmd = null;
        while ((cmd = parser.fetchCommand()) != null) 
        {
            //System.out.println(cmd);
            
            boolean result=false;
            
            if (cmd.getCommand().equals("help")) 
            {
                result = doHelp();

		    /* You need to implement all the following commands */
            } 
            else if (cmd.getCommand().equals("add_coach")) 
            {
            	String coach = cmd.getParameters()[0];
            	for(int i = 1; i < cmd.getParameters().length; i++) 
            	{
            		coach = coach + " " + cmd.getParameters()[i];
            	}
            	add_coach(coach);

            } 
        else if (cmd.getCommand().equals("add_team")) 
        {
        	String team = cmd.getParameters()[0];
        	for(int i = 1; i < cmd.getParameters().length; i++) 
        	{
        		team = team + " " + cmd.getParameters()[i];
        	}
        	add_team(team);
		} 
        else if (cmd.getCommand().equals("print_coaches")) 
        {
			print_coaches();
	   	} 
        else if (cmd.getCommand().equals("print_teams")) 
        {
	   		print_teams();
		} 
        else if (cmd.getCommand().equals("coaches_by_name")) 
        {
        	String coach_name = (cmd.getParameters()[0]);
        	coach_name = coach_name.replace('+', ' ');
        	coaches_by_name = true;
			search_Database(coach_name);
		} 
        else if (cmd.getCommand().equals("teams_by_city")) 
        {
        	String city = cmd.getParameters()[0];
        	city = city.replace('+', ' ');
        	teams_by_city = true;
			search_Database(city);
		} 
        else if (cmd.getCommand().equals("load_coaches")) 
        {			
        	load_coaches(cmd.getParameters()[0]);			
        } 
        else if (cmd.getCommand().equals("load_teams")) 
        {
        	load_teams(cmd.getParameters()[0]);
		} 
        else if (cmd.getCommand().equals("best_coach")) 
        {
        	int best_coach_by_year = Integer.parseInt(cmd.getParameters()[0]);
        	String coach_first = null;
        	String coach_last = null;
        	int top_wins = 0;
        	int temp_wins = 0;
        	
        	for (Coaches coaches : coaches) 
        	{
        		if(best_coach_by_year == coaches.season) 
        		{
        			temp_wins = ((coaches.seasonWin - coaches.seasonLoss) + (coaches.playoffWin - coaches.playoffLoss));
        			
        			if(temp_wins > top_wins) 
        			{
        				top_wins = temp_wins;
        				coach_first = coaches.firstName;
        				coach_last = coaches.lastName;
        			}      			
        		}
        	}
        	
        	System.out.println((coach_first + " " + coach_last));
		} 
        else if (cmd.getCommand().equals("search_coaches")) 
        {			
        	String search = cmd.getParameters()[0];
        	for(int i = 1; i < cmd.getParameters().length; i++) 
        	{
        		search = search + " " + cmd.getParameters()[i];
        	}
        	search_coaches = true;
			search_Database(search);
		} 
        else if (cmd.getCommand().equals("exit")) 
        {
			System.out.println("Leaving the database, goodbye!");
			break;
		} 
        else if (cmd.getCommand().equals("")) 
        {
		}
        else
        {
			System.out.println("Invalid Command, try again!");
        } 
            
	    if (result) 
        {
                // ...?
        }
            System.out.print("> "); 
        }        
    }
    
    private boolean doHelp() 
    {
        System.out.println("add_coach ID SEASON FIRST_NAME LAST_NAME SEASON_WIN "); 
        System.out.println("          EASON_LOSS PLAYOFF_WIN PLAYOFF_LOSS TEAM - add new coach data");
        System.out.println("add_team ID LOCATION NAME LEAGUE - add a new team");
        System.out.println("print_coaches - print a listing of all coaches");
        System.out.println("print_teams - print a listing of all teams");
        System.out.println("coaches_by_name NAME - list info of coaches with the specified name");
        System.out.println("teams_by_city CITY - list the teams in the specified city");
	    System.out.println("load_coach FILENAME - bulk load of coach info from a file");
        System.out.println("load_team FILENAME - bulk load of team info from a file");
        System.out.println("best_coach SEASON - print the name of the coach with the most netwins in a specified season");
        System.out.println("search_coaches field=VALUE - print the name of the coach satisfying the specified conditions");
		System.out.println("exit - quit the program");        
        return true;
    }
 
    public static void main(String[] args) 
    {
        new P1().run();
    }
    
    public void add_coach(String incString) 
    {
    	Coaches newCoach = new Coaches();
    	String str = incString;
    	str = str.replaceAll("(\\s*,\\s*)(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", ",");
    	String[] info = str.split(" ");
    	
    	for(int i = 0; i < info.length; i++) 
    	{
    		info[i] = info[i].replace('+', ' ');
    	}

    		newCoach.coachID = info[0];
    		newCoach.season = Integer.parseInt(info[1]);
    		newCoach.firstName = info[2];
    		newCoach.lastName = info[3];
    		newCoach.seasonWin = Integer.parseInt(info[4]);
    		newCoach.seasonLoss = Integer.parseInt(info[5]);
    		newCoach.playoffWin = Integer.parseInt(info[6]);
    		newCoach.playoffLoss = Integer.parseInt(info[7]);
    		newCoach.team = info[8];
    	
    		coaches.add(newCoach);   	
    }
    
    public void add_team(String incString) 
    {

    	Teams newTeam = new Teams();
    	
    	String[] info = incString.split(" ");    	
    	
    	for(int i = 0; i < info.length; i++) 
    	{
    		info[i] = info[i].replace('+', ' ');
    	}
    	
    	newTeam.teamID = info[0];
    	newTeam.location = info[1];
    	newTeam.name = info[2];
    	newTeam.league = info[3];
    	
    	teams.add(newTeam);
    	
    }
    
    public void load_coaches(String strings) 
    {
    	boolean fix = false;
    	
    	try 
		{
			File file = new File(strings);
			BufferedReader br = new BufferedReader(new FileReader(file));
			String str = br.readLine();
	
			while((str = br.readLine()) != null)
			{
				str = str.replaceAll("(\\s*,\\s*)(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", ",");
				String[] info = str.split("(\\s*,\\s*)(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
				Coaches newCoach = new Coaches();
				
				try 
				{
					newCoach.seasonWin = Integer.parseInt(info[4]);
				}
				catch(Exception ex)
				{
					fix = true;
				}			
				
				if(!fix) 
		    	{
		    		newCoach.coachID = info[0];
		    		newCoach.season = Integer.parseInt(info[1]);
		    		newCoach.firstName = info[2];
		    		newCoach.lastName = info[3];
		    		newCoach.seasonWin = Integer.parseInt(info[4]);
		    		newCoach.seasonLoss = Integer.parseInt(info[5]);
		    		newCoach.playoffWin = Integer.parseInt(info[6]);
		    		newCoach.playoffLoss = Integer.parseInt(info[7]);
		    		newCoach.team = info[8];
		    	
		    		coaches.add(newCoach);
		    	}
		    	else 
		    	{
		    		newCoach.coachID = info[0];
		        	newCoach.season = Integer.parseInt(info[1]);
		        	newCoach.firstName = info[3];
		        	newCoach.lastName = info[4];
		        	newCoach.seasonWin = Integer.parseInt(info[5]);
		        	newCoach.seasonLoss = Integer.parseInt(info[6]);
		        	newCoach.playoffWin = Integer.parseInt(info[7]);
		        	newCoach.playoffLoss = Integer.parseInt(info[8]);
		        	newCoach.team = info[9];
		        	
		        	coaches.add(newCoach);
		    	}
			}
			
			br.close();
		} 
		catch(Exception ex)
		{
			System.out.println("File isn't found.");
		}
    }
    
    public void load_teams(String incString) 
    {
    	try 
		{
			File file = new File(incString);
			BufferedReader br = new BufferedReader(new FileReader(file));
			String str = br.readLine();
	
			while((str = br.readLine()) != null)
			{
				str = str.replaceAll("(\\s*,\\s*)(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", ",");
				String[] info = str.split("(\\s*,\\s*)(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
				Teams newTeam = new Teams();
				
				newTeam.teamID = info[0];
		    	newTeam.location = info[1];
		    	newTeam.name = info[2];
		    	newTeam.league = info[3];
		    	
		    	teams.add(newTeam);
			}
			
			br.close();
		} 
		catch(Exception ex)
		{
			System.out.println("File isn't found.");
		}
    }
    
    public void print_coaches() 
    {    	
    	for (Coaches coaches : coaches) 
    	{
    	      System.out.println((coaches.coachID + "\t" + coaches.season + "\t" + coaches.firstName + "\t" + coaches.lastName + "\t" + coaches.seasonWin + "\t" + coaches.seasonLoss + "\t" + coaches.playoffWin + "\t" + coaches.playoffLoss + "\t" + coaches.team));
    	}

    }
    public void print_teams() 
    {
    	for (Teams teams : teams) 
    	{
    	     System.out.println((teams.teamID + "\t" + teams.location + "\t" + teams.name + "\t" + teams.league));
    	}
    }
    
    public void search_Database(String incString) 
    {
    	
    	if(teams_by_city) 
    	{
    		
    		for (Teams teams : teams) 
        	{

    			if(incString.equalsIgnoreCase(teams.location)) 
    			{
    	    	     System.out.println((teams.teamID + "\t" + teams.location + "\t" + teams.name + "\t" + teams.league));
    			}
        	} 
    		
    		teams_by_city = false;
    	}  	
    	else if(coaches_by_name) 
    	{
    		
    		for (Coaches coaches : coaches) 
        	{
    			if(incString.equalsIgnoreCase(coaches.firstName) || incString.equalsIgnoreCase(coaches.lastName)) 
    			{
    				System.out.println(coaches.coachID + "\t" + coaches.season + "\t" + coaches.firstName + "\t" + coaches.lastName + "\t" + coaches.seasonWin + "\t" + coaches.seasonLoss + "\t" + coaches.playoffWin + "\t" + coaches.playoffLoss + "\t" + coaches.team);
    			}
        	} 
    		
    		coaches_by_name = false;
    	}
    	else if(search_coaches)
    	{
    		ArrayList<Coaches> temp_coaches = new ArrayList<Coaches>();
    		String temp = incString.replace('=', ' ');
    		
    		int count = 0;
    		
    		String[] search = temp.split(" ");
    		
    		String para1_search = search[0];
    		String para1_find = search[1];
    		
    		
    		String para2_search = search[2];
    		String para2_find = search[3];


    		if(para1_search.equalsIgnoreCase("coachid")) 
    		{
    			for (Coaches coaches : coaches) 
            	{
    				if(para1_find.equalsIgnoreCase(coaches.coachID)) 
    				{
    					Coaches newCoach = new Coaches();
    					newCoach = coaches;
    					temp_coaches.add(newCoach);
    					count++;
    				}
            	}
    		}
    		
    		else if(para1_search.equalsIgnoreCase("year")) 
    		{
    			for (Coaches coaches : coaches) 
            	{
    				if(para1_find.equalsIgnoreCase(Integer.toString(coaches.season)))
    				{
    					Coaches newCoach = new Coaches();
    					newCoach = coaches;
    					temp_coaches.add(newCoach);
    					count++;
    				}
            	}
    		}
    		
    		else if(para1_search.equalsIgnoreCase("firstname")) 
    		{
    			for (Coaches coaches : coaches) 
            	{
    				if(para1_find.equalsIgnoreCase(coaches.firstName)) 
    				{
    					Coaches newCoach = new Coaches();
    					newCoach = coaches;
    					temp_coaches.add(newCoach);
    					count++;
    				}
            	}
    		}
    		
    		else if(para1_search.equalsIgnoreCase("lastname")) 
    		{
    			for (Coaches coaches : coaches) 
            	{
    				if(para1_find.equalsIgnoreCase(coaches.lastName)) 
    				{
    					Coaches newCoach = new Coaches();
    					newCoach = coaches;
    					temp_coaches.add(newCoach);
    					count++;
    				}
            	}
    		}
    		
    		else if(para1_search.equalsIgnoreCase("season_win")) 
    		{
    			for (Coaches coaches : coaches) 
            	{
    				if(para1_find.equalsIgnoreCase(Integer.toString(coaches.seasonWin))) 
    				{
    					Coaches newCoach = new Coaches();
    					newCoach = coaches;
    					temp_coaches.add(newCoach);
    					count++;
    				}
            	}
    		}
    		
    		else if(para1_search.equalsIgnoreCase("season_loss")) 
    		{
    			for (Coaches coaches : coaches) 
            	{
    				if(para1_find.equalsIgnoreCase(Integer.toString(coaches.seasonLoss)))
    				{
    					Coaches newCoach = new Coaches();
    					newCoach = coaches;
    					temp_coaches.add(newCoach);
    					count++;
    				}
            	}
    		}
    		
    		else if(para1_search.equalsIgnoreCase("playoff_win")) 
    		{
    			for (Coaches coaches : coaches) 
            	{
    				if(para1_find.equalsIgnoreCase(Integer.toString(coaches.playoffWin)))
    				{
    					Coaches newCoach = new Coaches();
    					newCoach = coaches;
    					temp_coaches.add(newCoach);
    					count++;
    				}
            	}
    		}
    		
    		else if(para1_search.equalsIgnoreCase("playoff_loss")) 
    		{
    			for (Coaches coaches : coaches) 
            	{
    				if(para1_find.equalsIgnoreCase(Integer.toString(coaches.playoffLoss)))
    				{
    					Coaches newCoach = new Coaches();
    					newCoach = coaches;
    					temp_coaches.add(newCoach);
    					count++;
    				}
            	}
    		}
    		
    		else if(para1_search.equalsIgnoreCase("team")) 
    		{
    			for (Coaches coaches : coaches) 
            	{
    				if(para1_find.equalsIgnoreCase(coaches.team)) 
    				{
    					Coaches newCoach = new Coaches();
    					newCoach = coaches;
    					temp_coaches.add(newCoach);
    					count++;
    				}
            	}
    		}
    		
    		if(para2_search.equalsIgnoreCase("coachid")) 
    		{
    			for (int i = 0; i < count; i++) 
            	{
    				//temp_coaches[i];
    				if(para2_find.equalsIgnoreCase(temp_coaches.get(i).coachID))
    				{
    					System.out.println(temp_coaches.get(i).coachID + "\t" + temp_coaches.get(i).season + "\t" + temp_coaches.get(i).firstName + "\t" + temp_coaches.get(i).lastName + "\t" + temp_coaches.get(i).seasonWin + "\t" + temp_coaches.get(i).seasonLoss + "\t" +temp_coaches.get(i).playoffWin + "\t" + temp_coaches.get(i).playoffLoss + "\t" + temp_coaches.get(i).team);
    				}
            	}
    		}
    		
    		else if(para2_search.equalsIgnoreCase("year")) 
    		{
    			for (int i = 0; i < count; i++) 
            	{
    				if(para2_find.equalsIgnoreCase(Integer.toString(temp_coaches.get(i).season)))
    				{
    					System.out.println(temp_coaches.get(i).coachID + "\t" + temp_coaches.get(i).season + "\t" + temp_coaches.get(i).firstName + "\t" + temp_coaches.get(i).lastName + "\t" + temp_coaches.get(i).seasonWin + "\t" + temp_coaches.get(i).seasonLoss + "\t" +temp_coaches.get(i).playoffWin + "\t" + temp_coaches.get(i).playoffLoss + "\t" + temp_coaches.get(i).team);
    				}
            	}
    		}
    		
    		else if(para2_search.equalsIgnoreCase("firstname")) 
    		{
    			for (int i = 0; i < count; i++) 
            	{
    				if(para2_find.equalsIgnoreCase((temp_coaches.get(i).firstName)))
    				{
    					System.out.println(temp_coaches.get(i).coachID + "\t" + temp_coaches.get(i).season + "\t" + temp_coaches.get(i).firstName + "\t" + temp_coaches.get(i).lastName + "\t" + temp_coaches.get(i).seasonWin + "\t" + temp_coaches.get(i).seasonLoss + "\t" +temp_coaches.get(i).playoffWin + "\t" + temp_coaches.get(i).playoffLoss + "\t" + temp_coaches.get(i).team);
    				}
            	}
    		}
    		
    		else if(para2_search.equalsIgnoreCase("lastname")) 
    		{
    			for (int i = 0; i < count; i++) 
            	{
    				if(para2_find.equalsIgnoreCase((temp_coaches.get(i).lastName)))
    				{
    					System.out.println(temp_coaches.get(i).coachID + "\t" + temp_coaches.get(i).season + "\t" + temp_coaches.get(i).firstName + "\t" + temp_coaches.get(i).lastName + "\t" + temp_coaches.get(i).seasonWin + "\t" + temp_coaches.get(i).seasonLoss + "\t" +temp_coaches.get(i).playoffWin + "\t" + temp_coaches.get(i).playoffLoss + "\t" + temp_coaches.get(i).team);
    				}
            	}
    		}
    		
    		else if(para2_search.equalsIgnoreCase("season_win")) 
    		{
    			//System.out.println("Got to the second else if");
    			for (int i = 0; i < count; i++) 
            	{
    				if(para2_find.equalsIgnoreCase(Integer.toString(temp_coaches.get(i).seasonWin)))
    				{
    					System.out.println(temp_coaches.get(i).coachID + "\t" + temp_coaches.get(i).season + "\t" + temp_coaches.get(i).firstName + "\t" + temp_coaches.get(i).lastName + "\t" + temp_coaches.get(i).seasonWin + "\t" + temp_coaches.get(i).seasonLoss + "\t" +temp_coaches.get(i).playoffWin + "\t" + temp_coaches.get(i).playoffLoss + "\t" + temp_coaches.get(i).team);
    				}
            	}
    		}
    		
    		else if(para2_search.equalsIgnoreCase("season_loss")) 
    		{
    			for (int i = 0; i < count; i++) 
            	{
    				if(para2_find.equalsIgnoreCase(Integer.toString(temp_coaches.get(i).seasonLoss)))
    				{
    					System.out.println(temp_coaches.get(i).coachID + "\t" + temp_coaches.get(i).season + "\t" + temp_coaches.get(i).firstName + "\t" + temp_coaches.get(i).lastName + "\t" + temp_coaches.get(i).seasonWin + "\t" + temp_coaches.get(i).seasonLoss + "\t" +temp_coaches.get(i).playoffWin + "\t" + temp_coaches.get(i).playoffLoss + "\t" + temp_coaches.get(i).team);
    				}
            	}
    		}
    		
    		else if(para2_search.equalsIgnoreCase("playoff_win")) 
    		{
    			for (int i = 0; i < count; i++) 
            	{
    				if(para2_find.equalsIgnoreCase(Integer.toString(temp_coaches.get(i).playoffWin)))
    				{
    					System.out.println(temp_coaches.get(i).coachID + "\t" + temp_coaches.get(i).season + "\t" + temp_coaches.get(i).firstName + "\t" + temp_coaches.get(i).lastName + "\t" + temp_coaches.get(i).seasonWin + "\t" + temp_coaches.get(i).seasonLoss + "\t" +temp_coaches.get(i).playoffWin + "\t" + temp_coaches.get(i).playoffLoss + "\t" + temp_coaches.get(i).team);
    				}
            	}
    		}
    		
    		else if(para2_search.equalsIgnoreCase("playoff_loss")) 
    		{
    			for (int i = 0; i < count; i++) 
            	{
    				if(para2_find.equalsIgnoreCase(Integer.toString(temp_coaches.get(i).playoffLoss)))
    				{
    					System.out.println(temp_coaches.get(i).coachID + "\t" + temp_coaches.get(i).season + "\t" + temp_coaches.get(i).firstName + "\t" + temp_coaches.get(i).lastName + "\t" + temp_coaches.get(i).seasonWin + "\t" + temp_coaches.get(i).seasonLoss + "\t" +temp_coaches.get(i).playoffWin + "\t" + temp_coaches.get(i).playoffLoss + "\t" + temp_coaches.get(i).team);
    				}
            	}
    		}
    		
    		else if(para2_search.equalsIgnoreCase("team")) 
    		{
    			for (int i = 0; i < count; i++) 
            	{
    				if(para2_find.equalsIgnoreCase((temp_coaches.get(i).team)))
    				{
    					System.out.println(temp_coaches.get(i).coachID + "\t" + temp_coaches.get(i).season + "\t" + temp_coaches.get(i).firstName + "\t" + temp_coaches.get(i).lastName + "\t" + temp_coaches.get(i).seasonWin + "\t" + temp_coaches.get(i).seasonLoss + "\t" +temp_coaches.get(i).playoffWin + "\t" + temp_coaches.get(i).playoffLoss + "\t" + temp_coaches.get(i).team);
    				}
            	}
    		}
    		
    		search_coaches = false;
    	}
    }
}