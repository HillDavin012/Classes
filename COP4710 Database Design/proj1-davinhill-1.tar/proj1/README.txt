This proj was creating by Davin Hill. I compiled this program on a linux machine, element.csee.usf.edu, and on my windows desktop using eclipse.

I compiled my code with everything in the same directory with the following commands.

To compile = "javac P1.java"
To run = "java P1"
