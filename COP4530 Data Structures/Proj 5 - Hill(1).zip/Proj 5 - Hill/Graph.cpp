#include "Graph.hpp"
#include <queue>


Edge::Edge()
{
	vertex1 = "";
	vertex2 = "";
	magnitude = 0;
}

Edge::~Edge()
{

}

void Graph::addEdge(string label1, string label2, unsigned long weight)
{
	//Create and pushback
	Edge *temp = new Edge();
	temp->vertex1 = label1;
	temp->vertex2 = label2;
	temp->magnitude = weight;
	vertex.push_back(temp);
}

void Graph::addVertex(string label)
{
	//Push label into mylist
	myVertexlist.push_back(label);
}

void Graph::removeVertex(string label)
{
	Edge *temp = new Edge();
	//Iterate through list finding matches to erase edges
	for (unsigned long i = 0; i < myVertexlist.size(); i++)
	{
		if (myVertexlist.at(i) == label)
		{
			//Erase first edge
			myVertexlist.erase(myVertexlist.begin() + i);
			for (i = 0; i < vertex.size(); i++)
			{
				temp = vertex.at(i);
				if (temp->vertex1 == label || temp->vertex2 == label)
				{
					//Erase second edge
					vertex.erase(vertex.begin() + i);
				}
			}
		}
	}
}

void Graph::removeEdge(string label1, string label2)
{
	Edge *temp = new Edge();
	for (unsigned long i = 0; i < vertex.size(); i++)
	{
		temp = vertex.at(i);
		//Finding matches to erase
		if (temp->vertex1 == label1 && temp->vertex2 == label2)
		{
			vertex.erase(vertex.begin() + i);
		}
	}
}

unsigned long Graph::shortestPath(string startLabel, string endLabel, vector<string> &path)
{
	//Creating a queue to hold what I have been through to not revist vertexes again
	priority_queue< pair<unsigned long, string>, vector <pair<unsigned long, string>>, greater<pair<unsigned long, string>> > myQueue;
	//Create a map with vertices and all their distances
	map<string, unsigned long> vertDist;
	//Another map to hold vertices
	map<string, string> myMap;
	for (const auto label : myVertexlist)
	{
		vertDist[label] = 99999999;
		myMap[label] = "STOP";
	}
	//Start que with origin
	myQueue.push(make_pair(0, startLabel));
	//Set distance from origin to 0
	vertDist[startLabel] = 0;

	//Go through entire queue
	while (!myQueue.empty())
	{
		//Hold top
		string temp = myQueue.top().second;
		//Pop my queue
		myQueue.pop();

		string tempStr2;

		//Go through connecting nodes
		for (auto currEdge : vertex)
		{
			if (currEdge->vertex1 == temp)
			{
				//Hold strings for shortest path
				tempStr2 = currEdge->vertex2;
			}
			else if (currEdge->vertex2 == temp)
			{
				//Hold strings for shortest path
				tempStr2 = currEdge->vertex1;
			}
			else
			{
				continue;
			}

			unsigned long weight = currEdge->magnitude;

			//Catch shortest paths
			if (vertDist[tempStr2] > vertDist[temp] + weight)
			{
				//Collect shortest path and make pair
				myMap[tempStr2] = temp;
				vertDist[tempStr2] = vertDist[temp] + weight;
				myQueue.push(make_pair(vertDist[tempStr2], tempStr2));
			}
		}
	}
	path.push_back(startLabel);
	//Start making the path
	makePath(myMap, endLabel, path);

	return vertDist[endLabel];
}

void Graph::makePath(map<string, string> parent, string endLabel, vector<string> &path)
{
	//Until it reaches stop from shortest path, keep going
	if (parent[endLabel] == "STOP")
	{
		return;
	}
	//Recursivly call to make path
	makePath(parent, parent[endLabel], path);
	//Finally add final destination
	path.push_back(endLabel);
}
