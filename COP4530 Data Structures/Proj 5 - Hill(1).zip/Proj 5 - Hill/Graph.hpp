#ifndef GRAPH_H
#define GRAPH_H
#include <list>
#include <iostream>
#include <set>
#include <string>
#include <vector>
#include <functional>
#include <unordered_map>
#include <tuple>
#include <limits.h>
#include <map>
#include "GraphBase.hpp"

using namespace std;

class Edge 
{
public:
	string vertex1;
	string vertex2;
	unsigned long magnitude;
	Edge();
	~Edge();

};

class Graph : public GraphBase
{
public:
	friend class Edge;
	vector<string> myVertexlist;
	vector<Edge*> vertex;

	void addEdge(string start, string end, unsigned long magnitude);
	void addVertex(string label);
	void removeVertex(string label);
	void removeEdge(string label1, string label2);
	unsigned long shortestPath(string startLabel, string endLabel, vector<string> &path);
	void makePath(map<string, string> parent, string endLabel, vector<string> &path);

};
#endif