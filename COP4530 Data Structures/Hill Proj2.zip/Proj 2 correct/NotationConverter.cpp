#include "NotationConverter.hpp"
#include <cstring>
#include <iostream>

//Constructor
DoubleDeque::DoubleDeque()
{
	head = nullptr;
	tail = nullptr;
	dequeLength = 0;
}

//Check if empty
bool DoubleDeque::empty() const
{
	return (head == nullptr);
}

//Returns size of Deque
int DoubleDeque::dequeSize() const
{
	return dequeLength;
}

//Get string in front
string DoubleDeque::first()
{
	if (empty())
	{
		return "Error, empty";
	}
	return head->nodeString;
}

//Get string from back
string DoubleDeque::back()
{
	if (empty())
	{
		return "Error, empty";
	}
	return tail->nodeString;
}

//Pushing node to front of deque
void DoubleDeque::pushToFront(string str)
{
	Node *temp = new Node;
	temp->nodeString = str;
	if (empty())
	{
		head = temp;
		tail = temp;
	}
	else
	{
		temp->next = head;
		temp->prev = nullptr;
		head = temp;
	}

	dequeLength++;
}

//Push string to back of deque
void DoubleDeque::pushToBack(string str)
{
	Node *temp = new Node;
	temp->nodeString = str;
	if (empty())
	{
		head = temp;
		tail = temp;
	}
	else
	{
		temp->prev = tail;
		temp->next = nullptr;
		tail = temp;
	}
	dequeLength++;
}

//Pops out front Node
void DoubleDeque::popFront()
{
	if (empty())
	{
		throw("Error, empty");
	}
	Node *temp = head;
	head = head->next;
	delete temp;

	dequeLength--;

}

//Pops back of deque
void DoubleDeque::popBack()
{
	if (empty())
	{
		throw("Error, empty");
	}
	Node *temp = tail;
	tail = tail->prev;
	delete temp;

	dequeLength--;
}

//Checking priority of operand
int NotationConverter::operPriority(string str)
{
	if (str == "+" || str == "-")
	{
		return 1;
	}
	else if (str == "*" || str == "/")
	{
		return 2;
	}
	return 0;
}

//Checking for only correct operand
bool NotationConverter::checkOper(string str)
{
	if (str == "+" || str == "-" || str == "*" || str == "/")
	{
		return true;
	}
	else
	{
		return false;
	}
}

//Make sure its only a character or digit
bool NotationConverter::isValid(string str)
{
	char ch[str.length() + 1];
	strcpy(ch, str.c_str());

	//Checking if character is operation
	if (checkOper(str))
	{
		return true;
	}
	else if (isalpha(ch[0]))
	{
		return true;
	}
	else if (isdigit(ch[0]))
	{
		return true;
	}
	else if (str == " " || str == "(" || str == ")")
	{
		return true;
	}
	else
	{
		return false;
	}
}

//PostFix to Infix
string NotationConverter::postfixToInfix(string inStr)
{
	int stringLength = inStr.length();
	string result = "";

	DoubleDeque Deque = DoubleDeque();

	//Goes through string, making sure input is correct
	for (int i = 0; i < stringLength; i++)
	{
		string position = string(1, inStr[i]);

		if (!isValid(position))
		{
			throw("Wrong input");
		}

		if (position == " " || position == "(" || position == ")")
		{
			continue;
		}
		//Collect new string and push to back
		else if (checkOper(position))
		{
			string p1 = Deque.back();
			Deque.popBack();
			string p2 = Deque.back();
			Deque.popBack();
			Deque.pushToBack("(" + p2 + " " + position + " " + p1 + ")");
		}
		else
		{
			Deque.pushToBack(position);
		}
	}
	//Send new string to tail, then send back results
	result = Deque.back();
	return result;
}

//Post to Prefix
string NotationConverter::postfixToPrefix(string inStr)
{
	int length = inStr.length();
	string result = "";

	DoubleDeque Deque = DoubleDeque();

	//Goes through string, making sure input is correct
	for (int i = 0; i < length; i++)
	{
		string position = string(1, inStr[i]);

		if (!isValid(position)) {
			throw("Wrong input");
		}
		if (position == " " || position == "(" || position == ")")
		{
			continue;
		}
		else if (checkOper(position))
		{
			string p1 = Deque.back();
			Deque.popBack();
			string p2 = Deque.back();
			Deque.popBack();
			
			//Putting together string, then pushing back
			string t = position + " " + p2 + " " + p1;
			Deque.pushToBack(t);
		}
		else
		{
			Deque.pushToBack(position);
		}
	}
	result = Deque.back();
	return result;
}

//Infix to Post
string NotationConverter::infixToPostfix(string inStr)
{
	int stringLength = inStr.length();
	string result = "";

	DoubleDeque Deque = DoubleDeque();

	//Goes through string, making sure input is correct
	for (int i = 0; i < stringLength; i++)
	{
		string posistion = string(1, inStr[i]);

		if (!isValid(posistion))
		{
			throw("Wrong input");
		}
		if (inStr[i] == ' ')
		{
			continue;
		}
		else if (isalpha(inStr[i]) || isdigit(inStr[i]))
		{
			result += posistion;
			result += " ";
		}
		else if (inStr[i] == '(')
		{
			Deque.pushToBack(posistion);
		}
		else if (inStr[i] == ')') {
			while (!Deque.empty() && Deque.back() != "(")
			{
				result += Deque.back();
				result += " ";
				Deque.popBack();
			}
			if (!Deque.empty())
			{
				Deque.popBack();
			}
		}
		else if (checkOper(posistion))
		{
			if (Deque.empty())
			{
				Deque.pushToBack(posistion);
			}
			else
			{
				while (!Deque.empty() && (Deque.back() != "(") && (operPriority(posistion) <= operPriority(Deque.back())))
				{
					result += Deque.back();
					result += " ";
					Deque.popBack();
				}
				Deque.pushToBack(posistion);
			}
		}
	}
	return result;
}

//Reused algorithms
string NotationConverter::infixToPrefix(string inStr)
{

	string infixToPost;
	string postToPreFix;
	infixToPost = infixToPostfix(inStr);
	postToPreFix = postfixToPrefix(infixToPost);
	return postToPreFix;

}

//Reused algorithms
string NotationConverter::prefixToInfix(string inStr)
{
	string prefixToPost;
	string postToInfix;
	prefixToPost = prefixToPostfix(inStr);
	postToInfix = postfixToInfix(prefixToPost);
	return postToInfix;
}

//Prefix to Post
string NotationConverter::prefixToPostfix(string inStr)
{
	int stringLength = inStr.length();
	string result = "";

	DoubleDeque Deque = DoubleDeque();

	//Goes through string, making sure input is correct
	for (int i = stringLength - 1; i >= 0; i--)
	{
		string position = string(1, inStr[i]);

		if (!isValid(position))
		{
			throw("Wrong input");
		}
		if (position == " ")
		{
			continue;
		}
		//Putting together string and pushing back
		else if (checkOper(position))
		{
			string p1 = Deque.back();
			Deque.popBack();
			string p2 = Deque.back();
			Deque.popBack();
			string newOperation = p1 + " " + p2 + " " + position;
			Deque.pushToBack(newOperation);
		}
		else
		{
			Deque.pushToBack(position);
		}
	}
	result = Deque.back();
	return result;
}