#include "NotationConverterInterface.hpp"
#include <string>

using namespace std;

struct Node
{
public:
	string nodeString;
	Node *next;
	Node *prev;
};

class DoubleDeque
{
public:
	DoubleDeque();
	bool empty() const;
	int dequeSize() const;
	void pushToFront(string str);
	void pushToBack(string str);
	void popFront();
	void popBack();

	Node *head;
	Node *tail;
	string first();
	string back();
	int dequeLength;
};


class NotationConverter : public NotationConverterInterface
{
public:
	int operPriority(string str);
	bool checkOper(string str);
	bool isValid(string str);

	std::string postfixToInfix(std::string inStr);
	std::string postfixToPrefix(std::string inStr);

	std::string infixToPostfix(std::string inStr);
	std::string infixToPrefix(std::string inStr);

	std::string prefixToInfix(std::string inStr);
	std::string prefixToPostfix(std::string inStr);
};


