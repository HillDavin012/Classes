#include "GritVM.hpp"
#include <list>
#include <string>
#include <map>
#include <vector>
#include <sstream>
#include <fstream>
#include <iostream>
#include <cctype>

using namespace std;

//LOAD STATUS
STATUS GritVM::load(const std::string filename, const std::vector<long> &initialMemory)
{
	//If other than waiting, return machine status
	if(machineStatus != WAITING)
	{
		return machineStatus;
	}

	//Setting up to open file
	ifstream inFile;
	inFile.open(filename);


	//Checking if we can open file
	if (!inFile.good())
	{
		throw("Can't open the file!");
	}
	else
	{
		//If good, change machine status to ready
		machineStatus = READY;
					
		//Pulling info from file
		while (getline(inFile, line))
		{

			if(line.empty() || line[0] == '#') continue;
			
			Instruction instruct = GVMHelper::parseInstruction(line);
			
			if(instruct.operation == UNKNOWN_INSTRUCTION) return machineStatus = ERRORED;

			instructMem.push_back(GVMHelper::parseInstruction(line));
		}
	}
	//Setting Datamem to input initial memory
	dataMem = initialMemory;		

	return instructMem.size() != 0 ? machineStatus = READY: machineStatus = WAITING;		
}



//STATUS RUN
STATUS GritVM::run()
{
	//Check Machine status
	switch(machineStatus)
	{
		case READY: 
			machineStatus = RUNNING; 
			break;

		case WAITING:
			break;

		case RUNNING: 
			break;

		case HALTED:
			GritVM::reset(); 
			break;

		case ERRORED: 
			GritVM::reset(); 
			break;

		case UNKNOWN: 
			GritVM::reset(); 
			break;
	} 
	//Connect ittorator to beggning of list
	currentInstruct = instructMem.begin();

	//Loop through list by each command
	while(machineStatus == RUNNING) 
	{
		
		switch(currentInstruct->operation)
		{
			
			case CLEAR:
				accumulator = 0;
				break;

			case AT:
				accumulator = dataMem.at(currentInstruct->argument); 
				break;

			case SET: 
				dataMem.at(currentInstruct->argument) = accumulator;
				break;

			case INSERT:
				dataMem.insert(dataMem.begin() + (currentInstruct->argument), accumulator);
				break;

			case ERASE:
				dataMem.erase(dataMem.begin() + currentInstruct->argument);
				break;

			case ADDCONST:
				accumulator = accumulator + currentInstruct -> argument; 
				break;

			case SUBCONST:
				accumulator = accumulator - currentInstruct -> argument; 
				break;

			case MULCONST:
				accumulator = accumulator * currentInstruct -> argument; 
				break;
	
			case DIVCONST:
				accumulator = accumulator / currentInstruct -> argument; 
				break;

			case ADDMEM:
				accumulator += dataMem.at(currentInstruct->argument); 
				break;

			case SUBMEM:
				accumulator -= dataMem.at(currentInstruct->argument); 
				break;

			case MULMEM:
				accumulator *= dataMem.at(currentInstruct->argument);
				break;

			case DIVMEM:
				accumulator /= dataMem.at(currentInstruct->argument); 
				break;

			case JUMPREL:
				//For negative jumps
				if(currentInstruct -> argument < 0)
				{
					for(int i = currentInstruct -> argument; i <= 0; i++)
					{
						currentInstruct--;
					}
				}
				//Else positive jumps
				else
				{
					
					for(int i = currentInstruct -> argument; i >= 0; i--)
					{
						currentInstruct++;
					}
				}
				
				break;
				
			case JUMPZERO:
				if(accumulator == 0)
				{
					//For negative jumps
					if(currentInstruct -> argument < 0)
					{
						for(int i = currentInstruct -> argument; i < 1; ++i)
						{
							currentInstruct--;
						}					
					}
					//Else positive jumps
					else
					{
					
						for(int i = currentInstruct -> argument; i > 1; --i)
						{
							currentInstruct++;
						}
					}
				}
				
				break;
			
			case JUMPNZERO:
				if(accumulator != 0)
				{
					//Negative jumps
					if(currentInstruct -> argument < 0)
					{
						for(int i = currentInstruct -> argument; i < 1; ++i)
						{
							currentInstruct--;
						}
					}
					//Else positive jumps
					else
					{
						for(int i = currentInstruct -> argument; i > 1; --i)
						{
							currentInstruct++;
						}
					}
				}
				break;
				
			case NOOP:
				//Just a filler step
				break;
				
			case HALT:
				machineStatus = HALTED;
				break;
			
			case OUTPUT:
				cout << accumulator << endl;
				break;
				
			case CHECKMEM:
				if(int(currentInstruct -> argument) <= int(dataMem.size()))
				{
					//We are good, continue
					break;
				}
				else
				{
					//Else argument was not less or equal to vector size
					machineStatus = ERRORED;
				}
	
				break; 
	
			case UNKNOWN_INSTRUCTION:
				machineStatus = ERRORED;
				break;

			default: 
				machineStatus = HALTED;
				break;
				
		}
		//Push list ittorator 1 instruction completed
		currentInstruct++;			
	}

	return machineStatus;
}

//get data memory
std::vector<long> GritVM::getDataMem()
{
    return dataMem;
}

STATUS GritVM::reset()
{

    accumulator = 0;
    machineStatus = WAITING;
    dataMem.clear();
    instructMem.clear();

    return machineStatus;
}















