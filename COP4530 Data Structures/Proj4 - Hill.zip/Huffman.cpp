#include "Huffman.hpp"

string HuffmanTree::compress(const string inputStr)
{
	//Create map and itterate through string counting
	map<char, int> count;

	for (char ch : inputStr)
	{
		count[ch]++;
	}

	//Insert into myHeap from map count and char
	for (auto mChar : count)
	{
		myHeap.insert(new HuffmanNode(mChar.first, mChar.second));
	}

	//Creating branches
	while (myHeap.size() > 1)
	{
		//Start with left node
		HuffmanNode *left = myHeap.min();
		myHeap.removeMin();

		//Create right node
		HuffmanNode *right = myHeap.min();
		myHeap.removeMin();

		//Add sum to input into new parent node and create null parent node
		sum = left->getFrequency() + right->getFrequency();
		myHeap.insert(new HuffmanNode('\0', sum, node, left, right));
	}

	//After loop, last node is root
	HuffmanNode *root = myHeap.min();

	map<char, string> encodedMap;
	//Send for traversal
	postorderTraversal(root);
	//Get encoded string
	encode(root, "", encodedMap);

	//Create string from returned end
	for (char ch : inputStr)
	{
		compressedStr += encodedMap[ch];
	}

	return compressedStr;
}


void HuffmanTree::encode(HuffmanNode *root, string str, map<char, string> &mapstr)
{
	//If doesn't exist return
	if (root == nullptr)
		return;

	// If root is leaf
	if (root->isLeaf())
	{
		mapstr[root->getCharacter()] = str;
	}
	// Go left and right encode recursivly
	encode(root->left, str + "0", mapstr);
	encode(root->right, str + "1", mapstr);

	if (root->isLeaf())
	{
		// Add 'L' and node character
		serialize.push_back('L');
		serialize.push_back(root->getCharacter());
	}
	// else this is not a leaf
	else
	{
		// Add 'B'
		serialize.push_back('B');
	}
}

string HuffmanTree::decompress(const string inputCode, const string serializedTree)
{
	// Stack to hold branches
	stack<HuffmanNode *> branch;

	for (int unsigned i = 0; i < serializedTree.length(); i++)
	{
		if (serializedTree[i] == 'L')
		{
			i++;

			//Get character
			char ch = serializedTree[i];

			// Create new character and push to stack
			HuffmanNode *newNode = new HuffmanNode(ch, 0, nullptr, nullptr, nullptr);
			branch.push(newNode);
		}
		else
		{
			//Create two new nodes
			HuffmanNode *newRight = branch.top();
			branch.pop();
			HuffmanNode *newLeft = branch.top();
			branch.pop();

			// Create new parent node
			HuffmanNode * newNode = new HuffmanNode(0, 0, nullptr, newLeft, newRight);

			// Push back to stack
			branch.push(newNode);
		}
	}

	// root is the top
	HuffmanNode * root = branch.top();
	HuffmanNode * curr;

	// to store if node found
	bool found = false;

	// start from left
	int unsigned i = 0;

	// string decode
	string decoded = "";

	// generate the symbols
	while (i < inputCode.length())
	{
		//  get the character
		if (!found)
		{
			// set the curr
			curr = root;

			// set finding to true
			found = true;
		}
		else
		{
			// if this is a character
			if (curr->isLeaf())
			{
				// set found to tree
				found = false;

				// add to result string
				decoded.push_back(curr->getCharacter());

			}
			else
			{
				// go left or right based on 0 or 1
				if (inputCode[i] == '0')
					curr = curr->left;
				else
					curr = curr->right;

				i++;
			}
		}
	}

	decoded.push_back(curr->getCharacter());
	return decoded;
}

void HuffmanTree::postorderTraversal(HuffmanNode * root)
{
	if (root == nullptr)
	{
		//Start left, then right
		postorderTraversal(root->left);
		postorderTraversal(root->right);

		// Check if this is a left node
		if (root->isLeaf())
		{
			cout << "L" << root->getCharacter();
			// Add 'L' and node character
			serialize.push_back('L');
			serialize.push_back(root->getCharacter());
		}
		// else this is not a leaf
		else
		{
			cout << "B";
			serialize.push_back('B');
		}
	}
}

string HuffmanTree::serializeTree() const
{
	return serialize;
}
