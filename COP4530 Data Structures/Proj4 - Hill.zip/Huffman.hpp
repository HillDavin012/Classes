#ifndef HUFFMAN_H
#define HUFFMAN_H
#include <iostream>
#include <string>
#include <stack>
#include <map>
#include "HuffmanBase.hpp"
#include "HeapQueue.cpp"


using namespace std;

class HuffmanTree : public HuffmanTreeBase
{
public:

	string compress(const string inputStr);
	string decompress(const string inputCode, const string serializedTree);
	void encode(HuffmanNode *root, string str, map<char, string> &mapstr);
	void postorderTraversal(HuffmanNode *root);
	string serializeTree() const;

private:
	HuffmanNode *node;
	HeapQueue<HuffmanNode*, HuffmanNode::Compare> myHeap;
	string compressedStr = "";
	string serialize = "";
	int sum;
};
#endif
