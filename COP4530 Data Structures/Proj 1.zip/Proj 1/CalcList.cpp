#include <iostream>
#include <iomanip>
#include <sstream>

#include "CalcList.hpp"

//Starting head of list null
//Constructor
List::List(): head(nullptr){}

//Destructor
List::~List()
{	
	//Goes through whole list and deletes everything, then even the head
	while(!isEmpty())
	{
		removeFront();
	} 
	delete head;
}

//Empty, return head == nullptr
bool List::isEmpty() const
{
	return head == nullptr;
}

//Counting number of nodes
int List::currCount() const
{
	Node *temp = head;
	int nodes = 0;
	//Loop through nodes
	while(temp != nullptr)
	{
		//Move Node to next position
		temp = temp -> next;
		//Increment nodes
		nodes++;
	}

	//Return number of nodes
	return nodes;
}

//Adding a new node
void List::addFront(NodeValue value)
{
	//Creating new node
	Node *newNode = new Node;
	//New nodes value is equal to input 
	newNode -> value = value;
	//Connecting new node and head
	newNode -> next = head;	
	//Making new node Head
	head = newNode;	
}

//Select points to front node and moves one, then deletes
void List::removeFront()
{
	Node *select = head; 
	head = head -> next; 
	delete select; 
}


//Return the value of all the nodes functions together
double CalcList::total() const
{
	return listTotal;
}


//New Operation
void CalcList::newOperation(const FUNCTIONS func, const double operand)
{
	double newTotal = 0.0;	
	std::string sign;
	
	//Accepts func and mathces with sign
	switch(func)
	{
		//newTotal is calculated depending on the sign
		case 
			ADDITION: sign = "+";
			newTotal = listTotal + operand;
		break;

		case 
			SUBTRACTION: sign = "-";
			newTotal = listTotal - operand;
		break;
		
		case
			MULTIPLICATION: sign = "*";
			newTotal = listTotal * operand;
		break;

		case
			DIVISION: sign = "/";
				//Can't divide by 0
				if(operand == 0)
				{
					throw(std::exception());
				}
				else
				{
					newTotal = listTotal / operand;
				}
		break;
	}
	
	//Collect all the information to create new node
	NodeValue nodeInput = {listTotal, operand, newTotal, sign};
	//Add to front
	nodeList.addFront(nodeInput);
	//Change final Total to new total after operation
	listTotal = newTotal;
} 

//Remove last operation
void CalcList::removeLastOperation()
{
	//Making sure there are nodes in list
	if(nodeList.isEmpty())
	{
		throw(std::exception());
	}
	else
	{
		//If there are nodes, remove
		nodeList.removeFront();

		//After removing, check if there is no nodes, if so reset to 0
		if (nodeList.isEmpty())
		{
			//Make sure listTotal = 0
			listTotal = 0.0;
		}
		//Else change to previous node total value
		else
		{
			listTotal = nodeList.head->value.result;
		}
	}
}

//Here output is turned into a string then returned as output
std::string CalcList::toString(unsigned short precision) const
{
	//Setting step to head of list
	Node *step = nodeList.head;
	
	//Setting numNodes to the amount of nodes in the list
	int numNodes = nodeList.currCount();

	//Creating output to begin with nothing
	std::string output = "";

	//While step still has a node keep going
	while(step != nullptr)
	{

		std::stringstream totalAtStep;
		std::stringstream operand;
		std::stringstream result;
		
		//Setting precision
		totalAtStep << std::fixed << std::setprecision(precision) << step -> value.totalAtStep;
		operand << std::fixed << std::setprecision(precision) << step -> value.operand;
		result << std::fixed << std::setprecision(precision) << step -> value.result;
		
		//Outputting results in string form
		output.append(std::to_string(numNodes) + ": " + totalAtStep.str() + step -> value.strvalue + operand.str() + "=" + result.str() + "\n");
	
		//Changing step to next node to output next node values
		step = step -> next;
		
		//Decrementing numNodes to it only iterates through the amount of nodes
		numNodes--;
	}

	//Return full output of string
	return output;
}














