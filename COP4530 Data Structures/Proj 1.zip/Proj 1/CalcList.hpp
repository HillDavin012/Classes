#ifndef CALCLIST_H
#define CALCLIST_H

#include "CalcListInterface.hpp"
#include <string>

class NodeValue
{
	public:
		double totalAtStep;
		double operand;
		double result;
		std::string strvalue;
};

class Node
{
	public:
		NodeValue value;
		Node *next;
};

class List
{
	public: 
		List();
		~List();
		bool isEmpty() const;
		int currCount() const;
		void addFront(NodeValue value);
		void removeFront();
		Node *head;
	
};

class CalcList:public CalcListInterface
{
	public:
		virtual double total() const;
		virtual void newOperation(const FUNCTIONS func, const double operand);
		virtual void removeLastOperation();
		virtual std::string toString(unsigned short precision) const;
	private:
		List nodeList;
		double listTotal = 0;
};


#endif
