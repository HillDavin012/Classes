// I pledge my Honor that I have not cheated, and will not cheat, on this assignment Davin Hill

import java.util.Scanner;
import java.text.NumberFormat;

//This program is to calculate what the future investment will be
public class Investment_Calc 
{
	public static void main (String[] args)
	{
		double Initial_Amount;
		double Interest_Rate;
		double Number_Of_Years;
		double Future_Value;
		double Interest_Rate_Calc;
		
		Scanner ReadInput = new Scanner(System.in);
		
		//Here is the only formating that appears to be allowed for this assignment
		NumberFormat Currency = NumberFormat.getCurrencyInstance();
		
		System.out.print("Initial investment value: ");
		Initial_Amount = ReadInput.nextDouble();
		
		System.out.print("Interest Rate: ");
		Interest_Rate = ReadInput.nextDouble();
		//Since we were not allowed to format % I just created another value to manipulate
		Interest_Rate_Calc = (Interest_Rate/100)/12 + 1;
		
		System.out.print("Number of Years: ");
		//Since this number is always going to be multiplied by 12, this makes my final equation cleaner
		Number_Of_Years = ReadInput.nextDouble()*12;
		
		//Here we calculate the final value
		Future_Value = Initial_Amount*Math.pow(Interest_Rate_Calc, Number_Of_Years);
		
		//This is the final print output for all the information
		System.out.println("Future Value of " 
		+ Currency.format(Initial_Amount) 
		+ " at an annual rate of " 
		+ Interest_Rate + "%"
		+ " is "
		+ Currency.format(Future_Value));
		
		ReadInput.close();
	}
}
