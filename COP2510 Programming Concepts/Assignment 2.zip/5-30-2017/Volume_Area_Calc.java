// I pledge my Honor that I have not cheated, and will not cheat, on this assignment Davin Hill

import java.util.Scanner;
import java.text.DecimalFormat;

//This program calculates Volume and Surface Area to 4 decimal places
public class Volume_Area_Calc 
{
	public static void main (String[] args)
	{
		double Radius;
		double Volume;
		double SurfaceArea;
		
		System.out.print("Please input radius:");
		
		//Here I am calling for formatting (4 decimal places) and Scanner and giving them names
		DecimalFormat DecFix = new DecimalFormat ("0.####");
		Scanner ReadInput = new Scanner(System.in);
		
		//Reading what the user put in for Radius
		Radius = ReadInput.nextDouble();
		
		//Here I had to move numbers into ( ) to have correct operations
		Volume = ((4*Math.PI)/3)*(Math.pow(Radius, 3));
		
		SurfaceArea = 4*Math.PI*(Math.pow(Radius, 2));
		
		//Here is the final output with formated 4 decimal points
		System.out.println("Volume: " + DecFix.format(Volume) + "\n"
		+"Surface Area: " + DecFix.format(SurfaceArea));
		
		ReadInput.close();
	}
}
