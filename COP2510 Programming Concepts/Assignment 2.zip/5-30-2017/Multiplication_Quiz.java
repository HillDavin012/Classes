// I pledge my Honor that I have not cheated, and will not cheat, on this assignment Davin Hill

import java.util.Scanner;
import java.util.Random;

//This program is to check the users answer against the correct answer
public class Multiplication_Quiz
{
	public static void main (String[] args)
	{
		int Rand1;
		int Rand2;
		int UserInput;
		int CorrectAnswer;
		
		Random Generate = new Random();
		
		Scanner ReadInput = new Scanner(System.in);
		
		//Generating my random numbers between 10-99
		Rand1 = Generate.nextInt(90) + 10;
		Rand2 = Generate.nextInt(90) + 10;
		
		//Here I stored the correct answer
		CorrectAnswer = Rand1 * Rand2;
		
		System.out.print("Find the answer (Only cheat with your brain!): "
				+ "\n" + Rand1 + " * " + Rand2 + " = ");
		
		UserInput = ReadInput.nextInt();
		
		//Here the program is checking the input against the correct answer
		if(CorrectAnswer == UserInput)
		{
			//Right!
			System.out.print("Correct! Good job cheating with your brain!");
		}
		else
		{
			//Wrong!
			System.out.print("Incorrect, the answer was " + CorrectAnswer);
		}
				
		ReadInput.close();
	}
}