// I pledge my Honor that I have not cheated, and will not cheat, on this assignment Davin Hill

import java.util.Scanner;

//Counts the vowels in the string you give
public class Vowel_Counter 
{
	public static void main(String[] args)
	{
		String UserInput;
		int StringLength;
		int aNumber = 0;
		int eNumber = 0;
		int iNumber = 0;
		int oNumber = 0;
		int uNumber = 0;
		
		Scanner ReadInput = new Scanner(System.in);
		
		System.out.print("Enter your string of characters: ");
		
		UserInput = ReadInput.nextLine();
		StringLength = UserInput.length();
		
		ReadInput.close();
			
		for(int i = 0; i < StringLength; i++)
		{
			
			char x = UserInput.charAt(i);
			{
				switch (x)
				{
				//"Fall through for both upper and lower case
				case 'A':
				case 'a':
					aNumber++;
					break;
				
				case 'e':
				case 'E':
					eNumber++;
					break;
				
				case 'i':
				case 'I':
					iNumber++;
					break;
					
				case 'o':
				case 'O':
					oNumber++;
					break;
					
				case 'u':
				case 'U':
					uNumber++;
					break;
				}
			}
		}
		
		
		System.out.print("\nNumber of each vowel in the string: "+ "\n"
				+ "a: " + aNumber + "\n"
				+ "e: " + eNumber + "\n"
				+ "i: " + iNumber + "\n"
				+ "o: " + oNumber + "\n"
				+ "u: " + uNumber);
		
	}
}
