// I pledge my Honor that I have not cheated, and will not cheat, on this assignment Davin Hill

import java.util.Scanner;
import java.text.NumberFormat;

//Calculating bank charges depending on how many checks you write
public class Bank_Charges 
{
	public static void main (String[] args)
	{
		int Checks_Written;
		final int Service_Fee = 10;
		final double Tier1 = .1;
		final double Tier2 = .08;
		final double Tier3 = .06;
		final double Tier4 = .04;
		double Cost_Total;
		
		Scanner Read_Input = new Scanner(System.in);
		NumberFormat Money = NumberFormat.getCurrencyInstance();
		
		System.out.print("Please enter number of checks you've written: ");
		
		Checks_Written = Read_Input.nextInt();
		
		//Checking to make sure correct input
		while (Checks_Written < 0)
		{
			System.out.print("Invalid input, please input 0 or greater: ");
			Checks_Written = Read_Input.nextInt();
		}
		
		// 19 or less checks
		if (Checks_Written <= 19 )
		{
			Cost_Total = Checks_Written * Tier1 + Service_Fee;
			System.out.print(Money.format(Cost_Total));
		}
		
		//20 - 39 Checks
		else if (Checks_Written >= 20 && Checks_Written <= 39 )
		{
			Cost_Total = Checks_Written * Tier2 + Service_Fee;
			System.out.print(Money.format(Cost_Total));
		}
		
		//40 - 59 Checks
		else if (Checks_Written >= 40 && Checks_Written < 59 )
		{
			Cost_Total = Checks_Written* Tier3 + Service_Fee;
			System.out.print(Money.format(Cost_Total));
		}
		
		// else, 60 or more Checks
		else
		{
			Cost_Total = Checks_Written * Tier4 + Service_Fee;
			System.out.print(Money.format(Cost_Total));
		}
		
		Read_Input.close();
	}
}