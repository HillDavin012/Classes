// I pledge my Honor that I have not cheated, and will not cheat, on this assignment Davin Hill

public class Limerick 
{
	public static void main (String[] args)
	{
		System.out.print("Here's a little limerick:"
				+ "\n\n\tThere was an old man with a beard,"
				+ "\n\t\twho said \"It is just as I feared!"
				+ "\n\tTwo owls and a hen,"
				+ "\n\t\tfour larks and a wren,"
				+ "\n\thave all build their nests in my beard!\""
				+ "\n\nThe end.");
	}
}
