// I pledge my Honor that I have not cheated, and will not cheat, on this assignment Davin Hill

public class DogVer2 
{

	private String name;
	private int age;
	private String quirks;
	private static int count;
	   
	
	public DogVer2(String n, int a, String q)
	{
		this.name = n;
	    this.age = a;
	    this.quirks = q;
	    
	    count++;
	}

	
	public DogVer2()
	{
	    this.name = " ";
	    this.age = 0;
	    this.quirks = " ";
	    
	    count++;
	}

	public String getName()
	{
	    return name;
	}
	   
	public int getAge()
	{
	   return age;
	}

	public String getQuirks()
	{
	   return quirks;
	}

	public void setName (String nameUp)
	{
	   this.name = nameUp;
	}
	  
	public void setAge (int ageUp)
	{
	   this.age = ageUp;
	}
	   
	public void setQuirks (String quirkUp)
	{
	   this.quirks = quirkUp;
	}
	   
	public int peopleYears()
	{
	   return age * 7;
	}
	
	public static int getCount()
	{
		return count;
	}

	public String toString()
	{
	   return "Dog: " + name + "\tAge: " + age + "\tPerson-Years: " 
	          + peopleYears() + "\tQuirks: " + quirks;
	}
}