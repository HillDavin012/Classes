// I pledge my Honor that I have not cheated, and will not cheat, on this assignment Davin Hill

import java.util.Scanner;

public class KennelVer2 
{
	public static void main(String[] pie)
	{
		Scanner UserInput = new Scanner (System.in);
		
		 //Create objects
	      DogVer2 dog1 = new DogVer2("Pico", 2, "Hates cats and bikes");
	      DogVer2 dog2 = new DogVer2("Kruger", 3, "Likes to butt bounce");
	      DogVer2 dog3 = new DogVer2();
	           
	      //toString
	      System.out.println(dog1);
	      System.out.println(dog2);
	      System.out.println(dog3);
	      
	      //Local Variables
	      String DogName;
	      String DogQuirks;
	      int DogAge;
	      
	      System.out.print("Enter the dog's name: ");
	      DogName  = UserInput.nextLine();
	         
	      System.out.print("Enter the dog's age: ");
	      DogAge  = UserInput.nextInt();
	      
	      DogQuirks  = UserInput.nextLine(); //to capture extra \n character
	      System.out.print("Enter the dog's quirks: ");
	      DogQuirks  = UserInput.nextLine();
	               
	      dog3.setName(DogName); 
	      dog3.setAge(DogAge);
	      dog3.setQuirks(DogQuirks);  
	               
	       //toString
	      System.out.println(dog1);
	      System.out.println(dog2);
	      System.out.println(dog3);
	      
	      dog1.setAge(dog1.getAge() + 1);
	      
	      System.out.println("Happy Birthday " + dog1.getName() + "! You are now "
	                         + dog1.getAge() + " which is " + dog1.peopleYears() +
	                         " years old in people years!"
	                         + "\n\nThis code provided info on " + DogVer2.getCount() + " dogs.");
	      
	      UserInput.close();
	}
	

}