// I pledge my Honor that I have not cheated, and will not cheat, on this assignment Davin Hill

import java.util.Scanner;
import java.io.*;
import javax.swing.JOptionPane;

public class Word_Count 
{
	public static void main (String[] pineapples)throws IOException
	{
		String UserWordRequest;
		int WordFrequency = 0;
		FileReader InputFile = new FileReader("TheRaven.txt");
		Scanner ReadFile = new Scanner(InputFile);
		
		JOptionPane.showMessageDialog(null, "This lets you see how many times a word " 
		+ "shows up in \"The Raven\" by Edgar Allen Poe.");
		
		UserWordRequest = JOptionPane.showInputDialog(null, "Enter a word to look for: ");


		while (ReadFile.hasNext())
		{
			String i = ReadFile.next();

			if (UserWordRequest.equalsIgnoreCase(i))
			{
				WordFrequency++;
			}
		}
		
		JOptionPane.showMessageDialog(null, UserWordRequest 
				+ " shows up " + WordFrequency + " times.");
	}
}