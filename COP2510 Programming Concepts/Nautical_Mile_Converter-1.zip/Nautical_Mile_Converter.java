// I pledge my Honor that I have not cheated, and will not cheat, on this assignment Davin Hill

// The goal of this program is to convert hard coded nautical miles, to kilometers and miles.
public class Nautical_Mile_Converter 
{
	public static void main (String[] args)
	{
		int NumberOfNauticalMiles = 150;
		final double Nautical_Kilometers = 1.852;
		final double Nautical_Miles = 1.150779;
		double Kilometers;
		double Miles;
		
		// Here I set the program to calculate to find the conversion to Kilometers
		Kilometers = (NumberOfNauticalMiles*Nautical_Kilometers);
		
		//Here I did the same but for miles
		Miles = (NumberOfNauticalMiles*Nautical_Miles);

		System.out.print(NumberOfNauticalMiles 
		+ " Nautical miles is equivalent to\n" 
		+ (Kilometers)
		+ " kilometers or " 
		+ (Miles) 
		+ " miles");
	}
}
