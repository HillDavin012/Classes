// I pledge my Honor that I have not cheated, and will not cheat, on this assignment Davin Hill

public class Sphere 
{
	   private double Volume;
	   private double Area;
	   private double Radia;

	public Sphere (double b, double c, double a)
	{
		Radia = a;
		Volume = b;
		Area = c;
	}

	public Sphere ()
	{
		Radia = 0;
		Volume = 0;
		Area = 0;
	}

	
	public double getVolume()
	{
		return Volume;
	}

	public double getArea()
	{
		return Area;
	}
	
	public double getRadius()
	{
		return Radia;
	}


	public void setVolume (double Radius)
	{
		Volume = ((4.0/3.0)*(Math.PI)*(Math.pow(Radius, 3)));
	}

	public void setArea (double Radius)
	{
		Area = (4*(Math.PI)*(Math.pow(Radius, 2)));
	}
	
	public void setRaduis (double Radius)
	{
		Radia = Radius;
	}

	public String toString()
	{
		return "Sphere Radius: " + Radia + " Volume: " + Volume + " Area: " + Area;
	}
}
