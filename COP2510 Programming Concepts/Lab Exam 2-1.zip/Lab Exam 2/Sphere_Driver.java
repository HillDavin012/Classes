// I pledge my Honor that I have not cheated, and will not cheat, on this assignment Davin Hill

import java.util.Scanner;
import java.text.DecimalFormat;

public class Sphere_Driver 
{
	public static void main(String[] args)
	{
		Scanner scan = new Scanner (System.in);
		DecimalFormat DecForm = new DecimalFormat("0.###");
		
		Sphere Sphere2 = new Sphere(381.704, 254.469, 4.5);
		Sphere Sphere1 = new Sphere();
		
		double Radius;
		
		System.out.print("Here is the initial information for the 2 spheres\n" + Sphere1.toString()
		 + "\n" + Sphere2.toString());
		
		
		System.out.print("\nEnter radius for a Sphere: ");
		Radius = scan.nextDouble();
		
		while(Radius < 0)
		{
			System.out.print("Radius must be positive: ");
			Radius = scan.nextDouble();
		}
		
		Sphere1.setVolume(Radius);
		Sphere1.setArea(Radius);
		Sphere1.setRaduis(Radius);
		
		System.out.print("Heres the final information for the 2 spheres: "
		+ "\nSphere radius: " + Sphere1.getRadius() + " Volume: " + DecForm.format(Sphere1.getVolume()) + " Area: "  + DecForm.format(Sphere1.getArea())
		+ "\n" + Sphere2.toString());
		

		
		scan.close();
	     
	}
}
