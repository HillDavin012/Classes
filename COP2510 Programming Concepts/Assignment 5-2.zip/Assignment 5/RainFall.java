// I pledge my Honor that I have not cheated, and will not cheat, on this assignment Davin Hill

import java.util.Scanner;
import java.text.DecimalFormat;

public class RainFall 
{
	
	public static void main (String[] args)
	{
		double UserRainfall;
		double Total = 0;
		Scanner UserInput = new Scanner(System.in);
		double [] Rainfall = new double [12];
		double Highest = Rainfall[0];
		int RainfallIndex_Highest = 0;
		int RainfallIndex_Lowest = 0;
		DecimalFormat DecForm = new DecimalFormat("0.##");
		String [] Months = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
		
		//Receives rainfall input and ensures positive value
		for(int i = 0; i < 12; i++)
		{
			System.out.print("Enter rainfall value for " + Months[(int) i] + ": ");
			UserRainfall = UserInput.nextDouble();
			Rainfall[(int) i] = UserRainfall;
			
			while(UserRainfall < 0)
			{
				System.out.print("Values must be 0 or more.\nPlease enter positive value for " + Months[(int) i] + ": ");
				UserRainfall = UserInput.nextDouble();
				Rainfall[(int) i] = UserRainfall;
			}
		}
		
		//Adds up all rainfall
		for (int i = 0; i < Rainfall.length; i++)
		{
			Total = Total + Rainfall[i];
		}
		
		//Finds highest rainfall
		for (int i = 0; i < Rainfall.length; i++)
		{
			if (Rainfall[i] > Highest) 
			{
				Highest = Rainfall[i];
				//Catches index of highest rainfall to correlate with month array
				RainfallIndex_Highest = i;
			}
		
		}
		
		//Finds lowest rainfall
		double Lowest = Rainfall[0];
		for (int i = 1; i < Rainfall.length-1; i++)
		{

			if (Rainfall[i] < Lowest)
			{
				Lowest = Rainfall[i];
				//Catches index of lowest rainfall to correlate with month array
				RainfallIndex_Lowest = i;
			}
		}
		
		System.out.print("The total rainfall for the year is " + Total + " inches." 
		+ "\n"
		+ "The average rainfall for the year is " + DecForm.format(Total/12) + " inches."
		+ "\n"
		+ "The largest amount of rainfall for the year is " + Highest + " inches in " + Months[RainfallIndex_Highest]
		+ "\n"
		+ "The smallest amount of rainfall for the year is " + Lowest + " inches in " + Months[RainfallIndex_Lowest]);
		
		UserInput.close();
	}
}
