// I pledge my Honor that I have not cheated, and will not cheat, on this assignment Davin Hill

import java.util.Scanner;

public class DiffMatrix 
{	
	public static void main(String[] args)
	{
		int[][]Matrix1 = new int [3][3];
		int[][]Matrix2 = new int [3][3];
		Scanner UserInput = new Scanner(System.in);
		int UserNumber;
		
		//User enters values for first matrix
		System.out.print("Enter Matrix 1: ");
		for (int i = 0; i < Matrix1.length; i++)
		{
			for(int j = 0; j < Matrix1[i].length; j++)
			{
				UserNumber = UserInput.nextInt();
				Matrix1[i][j] = UserNumber;
			}
		}
		
		//User enters values for second
		System.out.print("Enter Matrix 2: ");
		for (int i = 0; i < Matrix2.length; i++)
		{
			for(int j = 0; j < Matrix2[i].length; j++)
			{
				UserNumber = UserInput.nextInt();
				Matrix2[i][j] = UserNumber;
			}
		}
		
		//Matrix 1 and 2 sent to method Difference();
		Difference(Matrix1, Matrix2);
		
		System.out.println("\nThe difference of the matrices is: \n");
		
		//Prints out Matrix 1
		for(int i = 0; i < Matrix1.length; i++)
		{
		    for(int j = 0; j < Matrix1[i].length; j++)
		    {
		        System.out.print(Matrix1[i][j]);
		    }
		    System.out.println();
		}
		
		System.out.println("\n-\n");
		
		//Prints out Matrix 2
		for(int i = 0; i < Matrix2.length; i++)
		{
		    for(int j = 0; j < Matrix2[i].length; j++)
		    {
		        System.out.print(Matrix2[i][j]);
		    }
		    System.out.println();
		}
		
		System.out.println("\n=\n");
		
		//Prints out results from method Difference();
		for(int i = 0; i < Difference(Matrix1, Matrix2).length; i++)
		{
		    for(int j = 0; j < Difference(Matrix1, Matrix2)[i].length; j++)
		    {
		        System.out.print(Difference(Matrix1, Matrix2)[i][j]);
		    }
		    System.out.println();
		}
		
		UserInput.close();
		
	}
	
	//Method Difference(); receives both Matrices and returns new calculated value Matrix 3
	public static int[][] Difference(int Matrix1[][], int Matrix2[][])
	{
		int[][]Matrix3 = new int [3][3];
		
		for (int i = 0; i < Matrix1.length; i++)
		{
			for(int j = 0; j < Matrix1[0].length; j++)
			{
				Matrix3[i][j] = Matrix1[i][j] - Matrix2[i][j];
			}
		}
		
		return Matrix3;
	}
}
