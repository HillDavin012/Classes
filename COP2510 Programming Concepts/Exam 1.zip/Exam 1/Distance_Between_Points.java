// I pledge my Honor that I have not cheated, and will not cheat, on this assignment Davin Hill

import java.util.Scanner;
import java.text.DecimalFormat;

//This program calculates the distance between coordinate points
public class Distance_Between_Points 
{
	public static void main (String[] args)
	{
		double X1;
		double X2;
		double Y1;
		double Y2;
		double X3;
		double Y3;
		double Distance;
		
		Scanner ReadInput = new Scanner(System.in);
		//This Dec Format is for 3 decimal places
		DecimalFormat DecForm = new DecimalFormat("0.###");
		//This one is to clean them up to 1 decimal place
		DecimalFormat DecForm2 = new DecimalFormat("0");
		
		System.out.print("Enter the first x coordinate value: ");
		X1 = ReadInput.nextDouble();
		
		System.out.print("Enter the first y coordinate value: ");
		Y1 = ReadInput.nextDouble();
		
		System.out.print("Enter the second x coordinate value: ");
		X2 = ReadInput.nextDouble();
		
		System.out.print("Enter the second y coordinate value: ");
		Y2 = ReadInput.nextDouble();
		
		//I created extra variable to represent X2-X1 ect
		X3 = X2-X1;
		Y3 = Y2-Y1;
		
		//Here is where I calc the distance
		Distance = Math.sqrt((Math.pow(X3, 2)+(Math.pow(Y3, 2))));
		
		//Here is the final output of the program
		System.out.print("The distance between (" + DecForm2.format(X1) + "," + DecForm2.format(Y1) + ") "
				+ "and (" + DecForm2.format(X2) + "," + DecForm2.format(Y2) + ") is " + DecForm.format(Distance));
		
		ReadInput.close();
	}
}
