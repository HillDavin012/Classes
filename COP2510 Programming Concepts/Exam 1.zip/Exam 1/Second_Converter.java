// I pledge my Honor that I have not cheated, and will not cheat, on this assignment Davin Hill

import java.util.Scanner;

//This program converts seconds into hours, minutes, and seconds
public class Second_Converter 
{
	public static void main(String[] args)
	{
		final int Seconds_In_Hour = 3600;
		final int Seconds_In_Minute = 60;
		int User_Input;
		int Minutes;
		int Hours;
		int Seconds;
		
		Scanner ReadInput = new Scanner(System.in);
		
		System.out.print("Enter number of seconds: ");
		
		User_Input = ReadInput.nextInt();
		
		Hours = User_Input/Seconds_In_Hour;
		Minutes = (User_Input/Seconds_In_Minute)%Seconds_In_Minute;
		Seconds = (User_Input%Seconds_In_Minute);
				
		System.out.print("Hours: " + Hours + "\n"  
				+ "Minutes: " + Minutes + "\n"
				+ "Seconds: " + Seconds);
		
		ReadInput.close();
		
	}
}
