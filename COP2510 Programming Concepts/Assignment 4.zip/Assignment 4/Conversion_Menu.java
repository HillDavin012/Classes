// I pledge my Honor that I have not cheated, and will not cheat, on this assignment Davin Hill


//This program converts meters to yards, feet, or inches.
import java.util.Scanner;

public class Conversion_Menu 
{
	public static void main (String[] args)
	{
		String Continue = "yes";
		int UserInput_Menu;
		double UserInput_Convert;
		Scanner ReadInput_Menu = new Scanner(System.in);

		while(Continue.equalsIgnoreCase("yes"))
		{
			Menu();
			
			do
			{

				UserInput_Menu = ReadInput_Menu.nextInt();
			
				while(UserInput_Menu < 1 || UserInput_Menu > 3)
				{
					System.out.print("Please enter a number from 1-3: ");
					UserInput_Menu = ReadInput_Menu.nextInt();

				}
				
				System.out.print("Enter distance in meters: ");
				UserInput_Convert = ReadInput_Menu.nextDouble();
				
				while (UserInput_Convert <= 0)
				{
						System.out.print("Enter positive distance: ");
						UserInput_Convert = ReadInput_Menu.nextDouble();
				}
					

			}
			//Takes the meters the user inputed and sends them to be calculated in their respective methods
			while(UserInput_Convert < 0);
			{
				switch (UserInput_Menu)
				{
				case 1:
					Yards(UserInput_Convert);
					System.out.print(UserInput_Convert + " meters is equal to " + Yards(UserInput_Convert) + " yards.");
					break;
			
				case 2:
					Inches(UserInput_Convert);
					System.out.print(UserInput_Convert + " meters is equal to " + Inches(UserInput_Convert) + " inches.");
					break;
			
				case 3:
					Feet(UserInput_Convert);
					System.out.print(UserInput_Convert + " meters is equal to " + Feet(UserInput_Convert) + " feet.");
					break;
			
				}
			
			}
			
			//Asking user if they want to restart
			System.out.print("\n" + "\n" + "Do you want to restart this program?"
			+ "\n"
			+ "Type yes or no: ");
			Continue = ReadInput_Menu.next(); 
			
			}
		
			//Here is where the program ends
			ReadInput_Menu.close();
			System.out.print("Program terminated.");
	
		}

	//Here I just have a method to call to show the menu
	public static void Menu()
	{	
		System.out.print("\n" + "Hello!" 
				+ "\n" 
				+ "\n"
				+ "This program will convert a distance in meters to yards, inches, or feet!"
				+ "\n"
				+ "\n"
				+ "Select an option from the menu below to get started!"
				+ "\n"
				+ "\n"
				+ "1. Convert to yards" + "\n"
				+ "2. Convert to inches" + "\n"
				+ "3. Convert to feet" + "\n" + "\n"
				+ "Enter your choice: ");
	}
	
	//The methods accept the variable then compute a return
	public static double Yards(double UserInput_Convert)
	{		
		double YardsCalc = (UserInput_Convert * 1.09361);
		return YardsCalc;
	}
	
	public static double Inches(double UserInput_Convert)
	{
		double Inches = (UserInput_Convert * 39.3701);
		return Inches;
	}
	
	public static double Feet(double UserInput_Convert)
	{
		double Feet = (UserInput_Convert * 3.28084);
		return Feet;
	}
}