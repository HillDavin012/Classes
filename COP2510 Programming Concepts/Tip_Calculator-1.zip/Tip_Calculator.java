// I pledge my Honor that I have not cheated, and will not cheat, on this assignment Davin Hill

import java.util.Scanner;

//The goal of this program is to calculate tax and tip for your meal
public class Tip_Calculator 
{
	public static void main (String[] args)
	{
		
		final double TaxRate = .0675;
		final double TipRate = .15;
		double MealPrice;
		double Tax;
		double Tip;
		double FinalMealPrice;
		
		//Here I called for a new scanner and gave it a ReadInput Name
		Scanner ReadInput = new Scanner(System.in);
		
		System.out.print("Enter the charge for the meal: ");
		
		//Here I read what the user input was and assigned it a variable
		MealPrice = ReadInput.nextDouble();
		
		//Here I calculated the Tax by multiplying it by the base price
		Tax = (MealPrice * TaxRate);
		
		//I had to add the tax to the meal first before multiplying it by tip rate
		Tip = ((Tax + MealPrice) * TipRate);
		
		//To get the final meal price I had to add up all the costs added to the original bill
		FinalMealPrice = (Tip + MealPrice + Tax);
		
		//I like to add ( ) to make it look better and highlight what it is
		System.out.println("Meal Charge: $" + (MealPrice) + "\n" 
		+ "Tax: $" + (Tax) + "\n" 
		+ "Tip: $" + (Tip) + "\n"
		+ "Final Meal Price: $" + (FinalMealPrice));
		
		ReadInput.close();
	}
}
