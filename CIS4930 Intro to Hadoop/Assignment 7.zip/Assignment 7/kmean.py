import math
import sys
from pyspark import SparkContext

def closestPoint(p, points):
    bestIndex = 0
    closest = float("+inf")

    for i in range(len(points)):
        dist = distanceSquared(p,points[i])
        if dist < closest:
            closest = dist
            bestIndex = i
    return bestIndex
    

def distanceSquared(p1,p2):  
    return (p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2


def addPoints(p1,p2):
    return [p1[0] + p2[0], p1[1] + p2[1]]

def average(p,x):
	return (p[0]/x,p[1]/x)


filename = "/loudacre/devicestatus_etl/*"
    
K = 5

sc = SparkContext()

rdd = sc.textFile(filename)

convergeDist = .1
        
newLatLong = rdd.map(lambda line: (float(line.split(',')[3]),float(line.split(',')[4])))

newLatLongRDD = newLatLong.filter(lambda line: line !=(0,0))

newLatLongRDD.persist()


randomPoints = newLatLongRDD.takeSample(False, K,42)

tempDist = float("+inf")
while tempDist > convergeDist:
  
    index = newLatLongRDD.map(lambda line: (closestPoint(line,randomPoints),((line),1)))
	
   
    addIndex = index.reduceByKey(lambda line1, line2: ((addPoints(line1[0],line2[0])),line1[1] + line2[1]))
	
    newKey = addIndex.map(lambda line: (line[0], (average(line[1][0],line[1][1]))))
   
    newKeypoints = newKey.collect()
	
    tempDist = 0
	
    x = 0

    for p in randomPoints:
	tempDist = tempDist + distanceSquared(newKeypoints[x][1],p)
	randomPoints[x] = newKeypoints[x][1]
	x = x + 1


print("K mean points are")
for p in randomPoints:
	print(randomPoints.index(p),p)

print(" " )
print(" Temp dist is " ,tempDist)

