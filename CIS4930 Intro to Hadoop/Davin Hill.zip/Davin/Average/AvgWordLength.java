package stubs;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.util.ToolRunner;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class AvgWordLength extends Configured implements Tool 
{
	public  int run(String[] args) throws Exception 
   {
		if(args.length != 2) 
      {
			System.out.printf("Usage: %s [generic options] <indir> <outdir>\n", 
			getClass().getSimpleName());
			ToolRunner.printGenericCommandUsage(System.out);
			System.exit(-1);
		}

		Job myJob = new Job(getConf(), "AveWordLength");     
		myJob.setJarByClass(AvgWordLength.class);
		FileInputFormat.addInputPath(myJob, new Path(args[0]));    
		FileOutputFormat.setOutputPath(myJob, new Path(args[1]));
		myJob.setMapperClass(LetterMapper.class);
		myJob.setReducerClass(AverageReducer.class);
		myJob.setMapOutputKeyClass(Text.class);    
		myJob.setMapOutputValueClass(IntWritable.class);
		myJob.setOutputKeyClass(Text.class);   
		myJob.setOutputValueClass(FloatWritable.class);
		
      if(myJob.waitForCompletion(true))
      {
         return 0;
      }
      else
      {
         return 1;
      }
	}
	
	public static  void main(String[] args) throws Exception 
   {
		int endProg = ToolRunner.run(new AvgWordLength(), args);
		System.exit(endProg);
	}
}