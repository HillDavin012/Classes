package stubs;

import java.io.IOException;
import org.apache.hadoop.io.Text;
import java.util.StringTokenizer;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Mapper;

public class LetterMapper extends Mapper<Object, Text, Text, IntWritable> 
{

	public Text incText = new Text();
	public IntWritable sizeText = new IntWritable(1);
	
	public void map(Object letterKey, Text elements, Context cont) throws IOException, InterruptedException 
   {
		StringTokenizer stringTokenList = new StringTokenizer(elements.toString());
		
		while(stringTokenList.hasMoreTokens()) 
      {
			String found = stringTokenList.nextToken();
			incText.set(found.substring(0, 1));
			sizeText.set(found.length());
			cont.write(incText, sizeText);
		}
	}
}