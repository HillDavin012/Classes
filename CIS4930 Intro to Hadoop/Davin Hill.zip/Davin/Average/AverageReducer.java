package stubs;
import java.io.IOException;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.mapreduce.Reducer;

public class AverageReducer extends Reducer<Text, IntWritable, Text, FloatWritable> 
{
	public FloatWritable letterAvg = new FloatWritable();
	
	public  void reduce(Text keyLetter, Iterable<IntWritable> elements, Context context) throws IOException, InterruptedException 
   {
		int countLetters = 0;		
		int letterOccurance = 0;
      
		for(IntWritable val : elements) 
		{
			letterOccurance += val.get();
			countLetters++;
		}
		
		letterAvg.set((float)letterOccurance / countLetters);
      
		context.write(keyLetter, letterAvg);
	}
}